from pathlib import Path
import argparse,json,subprocess,hashlib
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);a=p.parse_args()
r=Path(__file__).resolve().parents[1];j=json.load(open(r/'candidate_manifest.json'))
(r/'sources').mkdir(exist_ok=True)
for x in j['images']:
 data=subprocess.check_output(['git','-C',a.repo,'cat-file','blob',x['source_git_blob']])
 assert hashlib.sha256(data).hexdigest()==x['source_sha256'],x['production_path']
 (r/x['source_file']).write_bytes(data)
print('Restored and SHA-verified all 16 original PNGs into this sandbox sources/. No repository file was written.')
