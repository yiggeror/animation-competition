from pathlib import Path
from PIL import Image
import json,hashlib
r=Path(__file__).resolve().parents[1];j=json.load(open(r/'candidate_manifest.json'));result=[]
for x in j['images']:
 p=r/x['production_path'];im=Image.open(p).convert('RGBA');a=Image.open(r/x['source_file']).convert('RGBA')
 rgba_ok=hashlib.sha256(im.tobytes()).hexdigest()==x['candidate_rgba_sha256']
 byte_ok=hashlib.sha256(p.read_bytes()).hexdigest()==x['candidate_sha256']
 alpha_ok=im.getchannel('A').tobytes()==a.getchannel('A').tobytes()
 assert rgba_ok and alpha_ok,x['production_path']
 result.append({'file':x['production_path'],'exact_rgba':rgba_ok,'exact_png_bytes':byte_ok,'alpha_exact':alpha_ok})
print(json.dumps(result,indent=2));print('All 16 reproduced exact RGBA and alpha. PNG byte mismatches alone can reflect encoder versions; use the frozen files for production.')
