from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
from scipy.ndimage import label, binary_dilation, binary_erosion, grey_closing, gaussian_filter
from pathlib import Path
import json,hashlib,sys,shutil
ROOT=Path(__file__).resolve().parents[1]
for _path in ['qa','masks','assets/chars/x13']:(ROOT/_path).mkdir(parents=True,exist_ok=True)
# Explicit, frame-specific semantic domains. Coordinates are original 1024x1536.
# Broad hair hulls are refined by connected regions from deliberate hair seeds,
# never used as a whole-image skin classifier. Skin neckline and arm boundaries
# are hand-traced to keep the collar and sleeves outside the skin domain.
CONFIG={
0:{'hair_poly':[(85,65),(690,65),(956,340),(935,835),(905,1008),(100,1018)],'hair_seeds':[(500,400),(230,880),(760,900)],
'skin_polys':[[(330,320),(860,320),(880,875),(633,876),(618,906),(620,940),(656,957),(665,981),(655,1000),(627,1020),(583,1038),(550,1026),(503,1008),(467,980),(436,950),(423,929),(446,902),(465,855),(470,803),(397,781),(348,738)],[(186,1342),(240,1347),(300,1361),(329,1358),(326,1460),(170,1460)],[(812,1346),(851,1343),(899,1329),(913,1372),(946,1460),(799,1460)]],
'feature_exclude':[[(575,584),(692,580),(697,713),(575,723)],[(768,574),(833,569),(833,702),(764,708)],[(713,773),(777,767),(775,818),(714,820)]],
'dress_poly':[(70,931),(1000,931),(1000,1463),(60,1463)]},
44:{'hair_poly':[(75,45),(680,45),(960,350),(941,834),(931,1007),(73,1029)],'hair_seeds':[(500,400),(230,880),(780,887)],
'skin_polys':[[(350,320),(898,320),(919,860),(692,853),(676,882),(659,910),(657,937),(680,945),(689,959),(688,980),(674,998),(648,1014),(615,1023),(574,1012),(527,991),(485,963),(461,942),(451,919),(463,903),(481,885),(498,835),(510,787),(430,784),(378,749)],[(187,1333),(237,1335),(301,1353),(345,1345),(326,1460),(166,1460)],[(824,1349),(872,1344),(922,1327),(955,1460),(805,1460)]],
'feature_exclude':[[(629,614),(755,602),(755,677),(625,688)],[(805,583),(879,578),(884,625),(805,635)],[(769,718),(840,715),(840,799),(769,808)]],
'dress_poly':[(66,928),(1018,928),(1018,1462),(65,1462)]},
78:{'hair_poly':[(67,40),(699,40),(975,330),(962,846),(957,1011),(67,1023)],'hair_seeds':[(500,400),(230,880),(795,900)],
'skin_polys':[[(350,320),(919,320),(931,861),(707,851),(693,882),(685,913),(680,936),(701,942),(711,962),(709,983),(697,1004),(675,1021),(650,1036),(627,1042),(589,1032),(554,1018),(509,991),(478,964),(460,940),(455,926),(470,913),(487,892),(511,828),(520,781),(429,785),(377,749)],[(183,1329),(238,1337),(296,1356),(343,1348),(324,1460),(162,1460)],[(824,1370),(865,1354),(934,1326),(967,1460),(804,1460)]],
'feature_exclude':[[(615,611),(750,600),(752,678),(615,688)],[(811,592),(890,589),(890,651),(808,658)],[(784,732),(842,731),(842,777),(783,780)],[(823,648),(856,648),(864,689),(825,690)]],
'dress_poly':[(60,930),(1020,930),(1020,1463),(58,1463)]},
100:{'hair_poly':[(40,40),(640,40),(941,360),(970,795),(1000,1016),(57,1025)],'hair_seeds':[(500,400),(235,897),(799,890)],
'skin_polys':[[(119,328),(655,318),(675,724),(645,770),(546,785),(570,872),(601,918),(636,934),(647,947),(646,968),(636,991),(618,1011),(590,1028),(559,1038),(529,1042),(488,1032),(448,1012),(413,983),(391,955),(381,936),(382,921),(402,910),(401,887),(384,851),(253,858),(167,795),(133,732)],[(104,1324),(156,1329),(208,1351),(257,1345),(244,1460),(79,1460)],[(791,1381),(842,1360),(923,1339),(956,1460),(792,1460)]],
'feature_exclude':[[(161,610),(220,612),(221,671),(162,676)],[(282,605),(423,604),(426,674),(285,680)],[(210,743),(260,743),(260,770),(209,771)],[(194,671),(224,671),(222,707),(191,712)]],
'dress_poly':[(2,932),(1020,932),(1020,1463),(2,1463)]},
}

BROWS={
0:[[(584,585),(608,551),(654,524),(682,516),(706,530),(677,536),(636,552),(607,571)],[(790,529),(801,515),(817,511),(834,522),(839,537),(819,526)]],
44:[[(580,585),(617,548),(679,519),(738,506),(725,526),(657,552),(608,571)],[(818,501),(829,492),(843,495),(860,510),(861,520),(843,511)]],
78:[[(582,585),(620,549),(678,523),(736,510),(724,529),(657,553),(606,573)],[(836,505),(853,502),(872,511),(883,526),(880,535),(861,521)]],
100:[[(155,556),(169,549),(191,545),(200,550),(178,558),(160,567)],[(267,540),(298,538),(343,546),(384,559),(416,575),(380,565),(334,555),(292,548)]]}
for _f,_polys in BROWS.items():CONFIG[_f]['feature_exclude']+=_polys

EYE_WHITES={
0:[[(590,630),(612,609),(650,604),(676,617),(687,651),(680,690),(657,710),(625,709),(600,693),(587,666)],[(779,620),(790,598),(805,592),(819,601),(821,646),(812,679),(793,692),(778,682)]],
44:[],
78:[[(619,661),(653,648),(690,638),(729,630),(733,652),(708,665),(672,670),(636,675)],[(818,629),(846,619),(876,614),(879,640),(853,647),(821,648)]],
100:[[(172,635),(194,636),(211,638),(210,656),(201,666),(177,669)],[(298,631),(316,634),(344,637),(370,640),(396,646),(391,655),(377,665),(358,671),(328,674),(304,670),(298,654)]]}
NOSE_GLOSS={0:[],44:[],78:[[(826,648),(849,649),(855,670),(846,687),(825,685)]],100:[[(197,672),(219,671),(220,694),(199,707),(190,702)]]}
for _f in CONFIG:CONFIG[_f]['eye_white_polys']=EYE_WHITES[_f];CONFIG[_f]['nose_gloss_polys']=NOSE_GLOSS[_f]

if (ROOT/'additional_semantic_domains.json').exists():
 CONFIG.update({int(k):v for k,v in json.load(open(ROOT/'additional_semantic_domains.json')).items()})

def poly_mask(polys,size):
 im=Image.new('L',size);d=ImageDraw.Draw(im)
 for p in polys:d.polygon(p,fill=255)
 return np.array(im)>0

def masks(f,rgba):
 c=CONFIG[f];rgb=rgba[:,:,:3].astype(float);r,g,b=rgb.transpose(2,0,1);a=rgba[:,:,3];h,w=a.shape
 alpha=a>220
 hp=poly_mask([c['hair_poly']],(w,h));sp=poly_mask(c['skin_polys'],(w,h));dp=poly_mask([c['dress_poly']],(w,h));fx=poly_mask(c['feature_exclude'],(w,h))
 # Broad raw hair-fill candidate within hand-drawn hull. Both skin and red
 # hair ornaments fail this predicate; small eye/mouth components are excluded.
 hc=hp & alpha & (r<215)&(g<165)&(b<145)&(g>r*.32)&(b>r*.17)&~fx
 # For connectivity only, include deep strokes so drawn strand lines do not
 # fracture a hair region; explicit feature exclusions prevent eye entry.
 connect=hc | (hp & alpha & (r<35)&(g<30)&(b<28)&~fx)
 labs,n=label(connect)
 ids=[]
 for x,y in c['hair_seeds']:
  v=labs[y,x]
  if not v: raise RuntimeError(f'{f}: bad hair seed {(x,y)}')
  ids.append(v)
 hair=np.isin(labs,ids)&hc
 # Explicit skin domains include light chin and jaw without saturation gating.
 # Their neck/cuff geometry excludes the white collar and dress entirely.
 neutral_face_white=(g>210)&(b>205)&((r-b)<30)
 eye_gray=(r>145)&(g>145)&(b>145)&(abs(r-b)<30)&(abs(g-b)<30)
 eye_seed=poly_mask(c['eye_white_polys'],(w,h)) & eye_gray
 eye_candidate=poly_mask(c['feature_exclude'][:2],(w,h)) & eye_gray
 eye_labels,_=label(eye_candidate)
 eye_ids=np.unique(eye_labels[eye_seed]);eye_ids=eye_ids[eye_ids>0]
 eye_white=np.isin(eye_labels,eye_ids) if len(eye_ids) else np.zeros((h,w),bool)
 nose_gloss=poly_mask(c['nose_gloss_polys'],(w,h)) & neutral_face_white
 mouth_domain=poly_mask([c['feature_exclude'][2]],(w,h))
 mouth_white=poly_mask(c.get('mouth_white_polys',[]),(w,h)) & eye_gray
 feature_pixels=eye_white | nose_gloss | mouth_white | (fx & (r<180)) | (mouth_domain & ((r-g)>55)&(b<195))
 skin=sp&alpha&(r>180)&(g>110)&(b>75)&~feature_pixels
 # The remaining states use individually located cuff/arm domains and skin
 # seeds so a hand-annotated cuff polyline cannot leave a pale skin sliver.
 if f not in [0,44,78,100]:
  for arm in c['skin_polys'][1:]:
   pts=np.array(arm);xmin,ymin=pts.min(0);xmax,ymax=pts.max(0)
   arm_domain=poly_mask([[(xmin-14,ymin-38),(xmax+14,ymin-38),(xmax+14,ymax+2),(xmin-14,ymax+2)]],(w,h))
   ac=arm_domain&alpha&(r>180)&(g>110)&(b>100)&((g-b)<80)&((r-b)>30)
   al,_=label(ac);sx=int((xmin+xmax)/2);sy=1420;aid=al[sy,sx]
   if aid==0:raise RuntimeError(f'{f} arm seed does not hit skin: {(sx,sy)}')
   skin |= (al==aid)

 # Protect true neutral specular pixels only; no broad white-skin rejection.
 specular=(r>249)&(g>247)&(b>241)
 neutral_white=(np.minimum(np.minimum(r,g),b)>175)&((np.maximum(np.maximum(r,g),b)-np.minimum(np.minimum(r,g),b))<30)
 collar_white=neutral_white & (np.indices(a.shape)[0]>875)
 skin &= ~collar_white & ~hair
 dress=dp&alpha&(r>175)&(g>115)&(b<135)&((r-b)>80)&((g-b)>60)&~(sp if f in [0,44,78,100] else skin)
 # Lock actual dark contours plus locally dark thin strokes. This is saved
 # independently and pixel-difference tested after every transform.
 lum=.2126*r+.7152*g+.0722*b
 ridge=grey_closing(lum,size=(7,7))-lum
 ink=((r<43)&(g<40)&(b<37)) | ((ridge>10)&(lum<45))
 # Exact deep-line lock; no source alpha or geometry is changed.
 # Domain masks retain every original contour coordinate.
 protect=ink
 region={'hair':hair,'skin':skin,'dress':dress}
 weights={}
 for k,raw in region.items():
  m=raw & ~protect
  smooth=m.astype(float)
  smooth[~raw|ink]=0
  weights[k]=smooth
  Image.fromarray((raw*255).astype('uint8')).save(ROOT/'masks'/f'F{f:03d}_{k}_semantic.png')
  Image.fromarray(np.round(smooth*255).astype('uint8')).save(ROOT/'masks'/f'F{f:03d}_{k}_edit_weight.png')
 Image.fromarray((ink*255).astype('uint8')).save(ROOT/'masks'/f'F{f:03d}_lineart_lock.png')
 Image.fromarray((feature_pixels*255).astype('uint8')).save(ROOT/'masks'/f'F{f:03d}_feature_exclusions.png')
 return region,weights,ink

def stats(arr,ms):
 return {k:{'mean_rgb':np.mean(arr[:,:,:3][m],axis=0).round(4).tolist(),'pixels':int(m.sum()),'std_rgb':np.std(arr[:,:,:3][m],axis=0).round(4).tolist()} for k,m in ms.items()}

def render_image(a,bg=(220,220,220)):
 im=Image.fromarray(a.astype('uint8'),'RGBA');out=Image.new('RGBA',im.size,(*bg,255));out.alpha_composite(im);return out.convert('RGB')

def run(frames):
 base=np.array(Image.open(ROOT/'sources/F000.png'));br,bw,bi=masks(0,base)
 ref={k:(w>.99) for k,w in bw.items()};ref_stats=stats(base,ref);target={k:np.array(v['mean_rgb']) for k,v in ref_stats.items()}
 results=[]
 for f in frames:
  a=np.array(Image.open(ROOT/'sources'/f'F{f:03d}.png'));reg,weights,ink=masks(f,a);core={k:w>.99 for k,w in weights.items()};before=stats(a,core);out=a.copy();params={}
  for k,w in weights.items():
   src=a[:,:,:3].astype(float);sel=core[k];mean=np.array(before[k]['mean_rgb']);t=target[k]
   if k=='hair':
    factor=t/mean; modified=src*factor
    params[k]={'method':'channel ratio, preserving relative shading','factor':factor.tolist()}
   else:
    delta=t-mean
    # Iteratively solve the offset after clipping, retaining per-pixel variation.
    for _ in range(8):
     pred=np.clip(src[sel]+delta,0,255);delta+=t-pred.mean(axis=0)
    modified=np.clip(src+delta,0,255);params[k]={'method':'channel offset, preserving absolute shading','delta':delta.tolist()}
   edited=np.round(src*(1-w[:,:,None])+modified*w[:,:,None]).clip(0,255).astype('uint8')
   active=w>0;out[:,:,:3][active]=edited[active]
  if f==0:out=a.copy()
  assert np.array_equal(out[:,:,3],a[:,:,3])
  assert np.array_equal(out[:,:,:3][ink],a[:,:,:3][ink])
  active=np.logical_or.reduce([w>0 for w in weights.values()]);assert np.array_equal(out[~active],a[~active])
  dest=ROOT/'assets/chars/x13'/f'F{f:03d}.png'
  if f==0:shutil.copy2(ROOT/'sources/F000.png',dest)
  else:Image.fromarray(out,'RGBA').save(dest)
  after=stats(out,core)
  results.append({'frame':f,'source_sha256':hashlib.sha256((ROOT/'sources'/f'F{f:03d}.png').read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'before':before,'after':after,'transform':params,'alpha_exact':True,'lineart_lock_exact':True,'outside_edit_masks_exact':True,'changed_pixels':int(np.any(a!=out,axis=2).sum())})
  src_im=render_image(a);dst_im=render_image(out);ov=np.array(src_im).astype(float)
  colors={'hair':np.array([35,150,255]),'skin':np.array([255,45,170]),'dress':np.array([30,225,80])}
  for k,raw in reg.items():ov[raw]=ov[raw]*.42+colors[k]*.58
  ov[ink & active]=np.array([0,0,0]);ov=Image.fromarray(ov.clip(0,255).astype('uint8'))
  panel=Image.new('RGB',(1536,804),(242,242,242));draw=ImageDraw.Draw(panel)
  for i,(im,title) in enumerate([(src_im,'ORIGINAL'),(dst_im,'PROPOSAL'),(ov,'EXPLICIT MASKS')]):
   panel.paste(im.resize((512,768)),(i*512,36));draw.text((i*512+12,10),f'F{f:03d}  {title}',fill='black')
  panel.save(ROOT/'qa'/f'F{f:03d}_original_proposal_masks.jpg',quality=96)
  # Full-size source and result on a common gray background support close review.
  dst_im.save(ROOT/'qa'/f'F{f:03d}_proposal_gray.png')
 json.dump({'reference':ref_stats,'results':results,'generation_calls':0},open(ROOT/'qa'/'measurements.json','w'),indent=2)
 json.dump(CONFIG,open(ROOT/'semantic_domains.json','w'),indent=2)
 sheet=Image.new('RGB',(1536,804*len(frames)),(242,242,242))
 for i,f in enumerate(frames):sheet.paste(Image.open(ROOT/'qa'/f'F{f:03d}_original_proposal_masks.jpg'),(0,804*i))
 sheet.save(ROOT/'qa'/('four_state_gate.jpg' if len(frames)==4 else 'all16_gate.jpg'),quality=95)
 print(json.dumps({'reference':ref_stats,'results':[{k:v for k,v in r.items() if k in ['frame','before','after','changed_pixels']} for r in results]},indent=2))
if __name__=='__main__':run(sorted(CONFIG) if '--all' in sys.argv else [0,44,78,100])
