from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,numpy as np
r=Path(__file__).resolve().parents[1];fs=[0,18,24,30,36,40,44,50,58,68,78,84,87,90,94,100]
j=json.load(open(r/'qa/measurements.json'));ref={k:np.array(v['mean_rgb']) for k,v in j['reference'].items()};measure={x['frame']:x for x in j['results']};old=json.load(open(r/'gate_reference.json'));gate={x['frame']:x['sha256'] for x in old['images']}
records=[]
def comp(p):
 im=Image.open(p);bg=Image.new('RGBA',im.size,(220,220,220,255));bg.alpha_composite(im);return bg.convert('RGB')
contact={k:Image.new('RGB',(1536,2400),(235,235,235)) for k in ['sources','candidates']}
for i,f in enumerate(fs):
 source=r/'sources'/f'F{f:03d}.png';dest=r/'assets/chars/x13'/f'F{f:03d}.png';a=np.array(Image.open(source));b=np.array(Image.open(dest));changed=np.any(a!=b,2)
 masks=[np.array(Image.open(r/'masks'/f'F{f:03d}_{k}_edit_weight.png'))>0 for k in ['hair','skin','dress']];raw_overlap=int((sum(x.astype(int) for x in masks)>1).sum());masks=[masks[0]&~masks[1]&~masks[2],masks[1]&~masks[2],masks[2]]
 for k,mask in zip(['hair','skin','dress'],masks):Image.fromarray((mask*255).astype('uint8')).save(r/'masks'/f'F{f:03d}_{k}_effective_edit_mask.png')
 edit=np.logical_or.reduce(masks);ink=np.array(Image.open(r/'masks'/f'F{f:03d}_lineart_lock.png'))>0;feat=np.array(Image.open(r/'masks'/f'F{f:03d}_feature_exclusions.png'))>0
 rgb=a[:,:,:3].astype(float);white=(rgb.min(2)>175)&((rgb.max(2)-rgb.min(2))<30)&(a[:,:,3]>220);white[:876]=False
 checks={'alpha_exact':np.array_equal(a[:,:,3],b[:,:,3]),'locked_lines_exact':np.array_equal(a[ink],b[ink]),'outside_edit_masks_exact':np.array_equal(a[~edit],b[~edit]),'protected_features_exact':np.array_equal(a[feat],b[feat]),'neutral_collar_dot_pixels_exact':not np.any(changed&white),'nonoverlapping_material_masks':not np.any(sum(x.astype(int) for x in masks)>1)}
 sha=hashlib.sha256(dest.read_bytes()).hexdigest()
 if f in gate:checks['approved_gate_sha_exact']=sha==gate[f]
 delta={k:(np.array(measure[f]['after'][k]['mean_rgb'])-ref[k]).round(4).tolist() for k in ref};checks['all_channel_means_within_4']=all(np.max(np.abs(v))<=4 for v in delta.values())
 checks={k:bool(v) for k,v in checks.items()}
 assert all(checks.values()),(f,checks)
 records.append({'frame':f,'production_path':f'assets/chars/x13/F{f:03d}.png','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':sha,'checks':checks,'mean_delta_vs_F000':delta,'changed_pixels':int(changed.sum()),'resolved_boundary_overlap_pixels':raw_overlap})
 imgs=[comp(source),comp(dest)]
 for typ,im in zip(['sources','candidates'],imgs):
  panel=contact[typ];x=(i%4)*384;y=(i//4)*600;panel.paste(im.resize((384,576)),(x,y+24));ImageDraw.Draw(panel).text((x+10,y+7),f'F{f:03d} {typ}',fill='black')
 if f<87:box=(570,550,915,842)
 elif f==87:box=(505,550,905,842)
 elif f==90:box=(200,550,585,835)
 else:box=(130,550,460,835)
 out=Image.new('RGB',((box[2]-box[0])*4,(box[3]-box[1])*2))
 for col,im in enumerate(imgs):out.paste(im.crop(box).resize(((box[2]-box[0])*2,(box[3]-box[1])*2)),(col*(box[2]-box[0])*2,0))
 out.save(r/'qa'/f'F{f:03d}_eye_mouth_before_after_2x.png')
 box=(300,870,780,1130);out=Image.new('RGB',(960,260))
 for col,im in enumerate(imgs):out.paste(im.crop(box),(col*480,0))
 out.save(r/'qa'/f'F{f:03d}_collar_before_after_1x.png')
 out=Image.new('RGB',(920,400))
 for col,im in enumerate(imgs):out.paste(im.crop((80,1260,1000,1460)),(0,col*200))
 out.save(r/'qa'/f'F{f:03d}_cuffs_before_after_1x.png')
for typ,im in contact.items():im.save(r/'qa'/f'01_all16_{typ}_contact.jpg',quality=96)
json.dump({'source_production_match':'Coordinator checked all 16 Git blobs against d558a91 assets/chars/x13','reference_gate':'gate_v4_frozen_1654','generation_calls':0,'records':records},open(r/'qa/full16_validation.json','w'),indent=2)
print('ALL 16 PASS; MAX MEAN ERROR',max(abs(t) for x in records for d in x['mean_delta_vs_F000'].values() for t in d))
