# S13 显式语义修色最小复现包

不含source PNG、candidate PNG、视频或大QA图。16个原图已在仓库历史；14个改变后的生产PNG由协调另传。F000与F018保持源文件原字节。

## 恢复与执行
1. 解压到新沙箱目录，不在仓库工作树里执行写图。
2. 使用含原对象的仓库克隆。协调已对固定源提交d558a91的assets/chars/x13逐图验证16/16一致；candidate_manifest.json内记录每张原Git blob与SHA256。
3. 运行：python scripts/restore_sources.py --repo /path/to/animation-competition
   只用git cat-file读原blob，将16源写入此包sources/；脚本逐图核SHA256，不修改仓库。
4. 依赖Pillow、NumPy、SciPy，实际版本见versions.json。
5. 运行：python scripts/semantic_color.py --all
   产生assets/chars/x13/的16张1024×1536 RGBA；同时重建显式mask、逐态原/修/mask QA、measurements。
6. 运行：python scripts/audit_full16.py
7. 运行：python scripts/verify_reproduction.py
   验证逐张候选RGBA像素SHA及alpha。当前相同依赖环境可字节复现；跨PNG编码器版本以RGBA像素SHA为准，生产采用另传的冻结PNG。

## 文件说明
- 两份domain JSON：semantic_domains.json是16态完整记录；additional_semantic_domains.json是脚本实际读入的新12态逐态域。4态基础域在实际脚本中，已独审过门。
- masks/*_semantic.png：几何/局部色域/种子连通得到的对象区域。
- masks/*_edit_weight.png：候选编辑域，深线稿、五官和透明边已排除。
- masks/*_effective_edit_mask.png：按最终归属消歧后的互斥实际落点。少量发/肩AA边界原域有0–34像素交叠，按裙→肤→发归属，不叠加双次色变。数量在qa/full16_validation.json。
- masks/*_lineart_lock.png、*_feature_exclusions.png：深线稿及真实眼白/灰影/虹膜光点/鼻亮点/口部保护。
- qa/仅保留机器审计数值，没有大图；sources_manifest.json与candidate_manifest.json分别记录源和候选；gate_reference.json锁4态已过门SHA。

## 方法与边界
每态单独的发部、面颈臂、裙域和眼球域，眼白含灰影按局部连通区域保护，袖口独立小域补齐浅肤边。头发通道比例保留光泽层次，皮肤/裙通道偏移保留原有色阶。alpha、深线稿、保护五官、有效mask外RGBA逐像素不变。均色最大单通道差0.4959，仅辅助实际图审。

尾发外翘属原稿几何，未改；动作、时序、主模块、音频均未改。正式16态曝光0/18/24/30/36/40/44/50/58/68/78/84/87/90/94/100，最后hold20；120f/24fps的隔离色审片另传，不能代替生产全镜重渲。

总生图调用0。请保留冻结原件；复现应在新目录进行。
