# 《来电》S29 整段修复制作增量

本包对应 **272 帧、24 fps，即 11 秒 8 帧（11⅓ 秒）**。时长沿用上一轮完整候选，比原 12 秒少 16 帧（⅔ 秒）；本轮没有继续裁短。完整 MP4 单独交付，不装入制作包。

实际入口和原速播放的结果以 `records/` 内本次实际记录为准。

## 基线与接入范围

本轮是在保留后段 11 张动作、色修和靠灯准备动作的**完整累计工作副本**上修复。实际读取的工作副本 Git HEAD 为 `d7f6a646991506712f9d4bf13a1d4dc3fa132df0`，它不能代表累计工作树；增量比较基线是本轮保存的 `baseline/` 与 `BASELINE.json`。

团队前段输入来自 `73271df4e439015bbf58a1c104952a0e473929ef` 的 `collab/reviews/20261020_s29_front_continuity_repair/actual_entry/served_tree/`。交付前重读到 `3f10d080dcd196aed153b9c11129cab9eef922dd`，该目录相对输入提交没有变化，见 `LATEST_TEAM_INPUT_CHECK.json`。

**本包须接到完整的上一轮累计工作副本，不能套到裸 `d7f6` 分支或其他缺少后段、结尾依赖的快照。**

## 本轮实际增量

- 16 张采用 PNG：F000、024、057、075、078、081、084、090、093、096、099、102、108、120、123、126。唯一生产版本放在 `production/assets/chars/s29/`，不重复放一套 adopted 图。
- 新增 **4 张不同动作画**：F057 落掌、F075 抓布手落下的过渡、F123 与 F126 提布覆盖过渡。另有 **1 张完整左臂修源**，应用于 10 张既有姿态；不把这些复用修源计成 10 张新动作。
- 团队固定人凳的 F000/024、前段过渡与手部修复已并入；重建戴绿镯左臂的肩、袖窿、上臂、肘、腕连接，局部修复远侧裤腿接片和贴地影。
- 原鹤、龟及四杆采用原素材同坐标像素，随真实新布折遮挡。原始生成结果只收 5 张选用版本；未采用尝试、旧视频、旧大包及无关预览不收录。
- S29 代码只交 `changes.patch` 中相对本轮基线的 unified diff，不整份覆盖 `s29.js`。小满转头、F132 手机、F195–203 回头、F240 开始靠灯准备的事件时点保留。奶奶只鼓腮准备吹，油灯一直亮着。

S30 共用冻结影子、音轨和全片 EDL 未改；未推送共享分支。文件清单和最终生产 SHA-256 以 `MANIFEST_SHA256.json`、`ADOPTED_ASSETS.json` 为准；`*_COMPOSITE.json` 记录的是后续裤腿局部修复之前的合成阶段。

## 接入完整上一轮工作副本

将下面两个路径换成实际路径。先让补丁检查现有代码上下文，再应用本轮代码 hunks 与 16 张生产图。

```sh
S29_WORKCOPY=/path/to/complete_previous_s29_workcopy
S29_INCREMENT=/path/to/S29_FULL_REPAIR_INCREMENT
git -C "$S29_WORKCOPY" apply --check "$S29_INCREMENT/changes.patch"
git -C "$S29_WORKCOPY" apply "$S29_INCREMENT/changes.patch"
cp -a "$S29_INCREMENT/production/assets/." "$S29_WORKCOPY/assets/"
```

如果相同位置已有新的团队改动，请按补丁上下文合并；不要用旧入口文件覆盖它们。

## 复现原画合成

现成生产 PNG 可以直接接入；以下仅用于使用包内生成原件重做同一次采用合成。脚本需要 Python、Pillow、NumPy、SciPy；不需要重新调用生图。

先从输入提交提取母图。`S29_WORKCOPY` 指向已有该提交对象的仓库，`S29_INCREMENT` 指向解压后的制作包。

```sh
mkdir -p "$S29_INCREMENT/input_front" "$S29_INCREMENT/baseline/assets/chars/s29" "$S29_INCREMENT/adopted"
git -C "$S29_WORKCOPY" archive 73271df4e439015bbf58a1c104952a0e473929ef collab/reviews/20261020_s29_front_continuity_repair/actual_entry/served_tree/ | tar -xf - -C "$S29_INCREMENT/input_front" --strip-components=5
cp "$S29_WORKCOPY/assets/chars/s29/F054.png" "$S29_INCREMENT/baseline/assets/chars/s29/F054.png"
cp "$S29_WORKCOPY/assets/chars/s29/F072.png" "$S29_INCREMENT/baseline/assets/chars/s29/F072.png"
python "$S29_INCREMENT/tools/compose_left_arm.py"
python "$S29_INCREMENT/tools/compose_lowering_hand.py"
python "$S29_INCREMENT/tools/compose_lift_inbetweens.py"
python "$S29_INCREMENT/tools/repair_trouser_join.py" --frames 90 93 96 99 102 108 120 123 126 --output-dir "$S29_INCREMENT/reproduced_trouser_join"
```

最后一个脚本把裤腿局部修复放到单独输出目录。将 `reproduced_trouser_join/assets/` 中的 9 张输出覆盖到重建的 `adopted/`，即可得到最终采用版本；不需要重新生成图片。采用顺序、输入 SHA 与遮罩见三个 `*_COMPOSITE.json`、`records/TROUSER_JOIN.json` 及 `masks/`。团队 F000/024 直接使用已交生产图。

## 通过正式入口复现画面与播放

`EXPOSURE.csv` 来自最终正式模块。实际渲染入口为 `js/paint/shots/s29.js`，通过仓库原有 `dev/view.html` 加载；以下命令需要本地 Chromium、Playwright 与 FFmpeg。输出目录须是新的目录。

```sh
node "$S29_INCREMENT/tools/render_entry_frames.cjs" --repo "$S29_WORKCOPY" --out ./s29_actual_reproduction --chromium "$CHROMIUM_PATH" --first 0 --last 271 --duration 11.333333333333334
node "$S29_INCREMENT/tools/play_complete_video.cjs" --video ./s29_actual_reproduction/S29_F000_F271.mp4 --out ./s29_actual_playback.json --chromium "$CHROMIUM_PATH"
```

播放日志记录实际执行情况，人物形体、手布接触与表演连续性仍以实际画面复看记录为准。
