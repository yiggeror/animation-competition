#!/usr/bin/env python3
"""Bake the generated full shoulder-to-wrist repair into registered S29 cels.
No arm transform, person registration, puppet redraw, or frame interpolation.
"""
from pathlib import Path
import json, hashlib, io, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import binary_dilation

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent/'s29_repo'
RAW=ROOT/'raw/left_arm_master_v1.png'
IDS=[78,81,84,90,93,96,99,102,108,120]
# Includes the complete image-right shoulder, sleeve, upper arm, elbow,
# forearm and wrist, plus the small cloth fold held by the new grip.
# The left boundary lies inside the adjacent shirt panel, never on the old
# incorrect limb contour; that old contour is fully removed.
POLYGON=[(494,345),(548,348),(620,409),(663,498),(714,590),
         (758,669),(760,791),(708,802),(641,798),(577,765),
         (528,740),(486,728),(479,689),(485,640),(497,584),
         (507,541),(504,485),(504,427),(497,389)]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save_png_verified(im, path):
    buffer=io.BytesIO(); im.save(buffer,format='PNG'); payload=buffer.getvalue()
    Image.open(io.BytesIO(payload)).load()
    temp=path.with_suffix('.writing.png')
    with temp.open('wb') as stream:
        stream.write(payload);stream.flush();os.fsync(stream.fileno())
    Image.open(temp).load()
    if temp.read_bytes()!=payload:raise OSError('PNG write differs from encoded bytes: '+str(path))
    os.replace(temp,path)
mask=Image.new('L',(1024*4,1536*4),0)
ImageDraw.Draw(mask).polygon([(x*4,y*4) for x,y in POLYGON],fill=255)
mask=mask.resize((1024,1536),Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(.8))
base_mask=np.array(mask)
out=ROOT/'adopted';out.mkdir(exist_ok=True)
mask_dir=ROOT/'masks';mask_dir.mkdir(exist_ok=True)
records=[]
for f in [75]+IDS:
    name=f'F{f:03}.png'
    source=ROOT/'baseline/assets/chars/s29/F072.png' if f==75 else ROOT/'input_front/assets/chars/s29'/name
    repair=ROOT/'raw/F075_v2.png' if f==75 else RAW
    raw=np.array(Image.open(repair).convert('RGBA'))
    old=np.array(Image.open(source).convert('RGBA'))
    assert old.shape==raw.shape==(1536,1024,4)
    m=base_mask.copy()
    if f==75:
        # F075's real cloth rim descends with its new pinch. Carry that drawn
        # rim through to the outside silhouette, so a fixed arm-region edge
        # cannot cut a vertical step into the cloth at x=760.
        edge=Image.new('L',(1024*4,1536*4),0)
        ImageDraw.Draw(edge).polygon([(x*4,y*4) for x,y in
            [(710,688),(1024,688),(1024,845),(900,820),(790,809),(710,797)]],fill=255)
        edge=edge.resize((1024,1536),Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(.8))
        m=np.maximum(m,np.array(edge))
    # Keep original visible crane ink/fill where both source and repair still
    # show the same exposed puppet; the newly drawn hand and blue pinch fold
    # may occlude it. This never invents or translates a puppet or rod.
    y,x=np.indices(old.shape[:2])
    def ochre(a):
        q=a[:,:,:3].astype(np.int16)
        return (q[:,:,0]>65)&(q[:,:,0]>q[:,:,1]+18)&(q[:,:,1]>q[:,:,2]+12)&(q[:,:,2]<105)
    # Every exposed puppet/rod mark comes from the original delivered cel.
    # The generated hand and the small cloth pinch in front can occlude it,
    # but generated replacement gold ink is never adopted.
    roi=(y>738)&(y<880)&(x>500)
    def prop_gold(a):
        return ochre(a)&(a[:,:,0]<215)&(a[:,:,3]>160)&roi
    props=binary_dilation(prop_gold(old)|prop_gold(raw),iterations=2)
    props|=(x>=618)&(x<=641)&(y>=790)&(y<880)
    rgb=raw[:,:,:3].astype(np.int16)
    skin=(rgb[:,:,0]>190)&(rgb[:,:,0]>rgb[:,:,1]+15)&(rgb[:,:,1]>rgb[:,:,2]+15)&(raw[:,:,3]>128)
    skin=binary_dilation(skin,iterations=2)
    fold=Image.new('L',(1024,1536),0)
    ImageDraw.Draw(fold).polygon([(600,752),(630,746),(667,746),(700,754),
        (722,774),(706,780),(648,780),(612,777)],fill=255)
    cloth=(rgb[:,:,2]>=rgb[:,:,0]-5)&(rgb[:,:,2]>=rgb[:,:,1])&(raw[:,:,3]>128)
    foreground=(np.array(fold)>0)&cloth
    org=old[:,:,:3].astype(np.int16)
    # Exclude the former grip's warm antialiased outline from ochre-ink
    # restoration; otherwise an old fingertip could reappear beside the new one.
    former_hand=(org[:,:,0]>215)&(org[:,:,1]>145)&(org[:,:,2]>80)&(x>595)&(x<715)&(y>695)&(y<772)
    former_hand=binary_dilation(former_hand,iterations=4)
    # Keep the complete original prop-bearing cloth face, not isolated
    # color speckles. Only the new pinch fold and the former hand footprint
    # need the new drawn cloth. This also avoids clipped flower fragments.
    rim_only=np.zeros(m.shape,dtype=bool)
    if f==75:
        for xx in range(735,1024):
            a=np.flatnonzero(old[650:930,xx,3]>128)
            b=np.flatnonzero(raw[650:930,xx,3]>128)
            if len(a) and len(b):
                bottom=650+max(int(a[0]),int(b[0]))+10
                rim_only[650:bottom,xx]=True
    preserve_cloth=(y>=738)&(x>=480)&~skin&~foreground&~former_hand&~rim_only
    restore=props&~skin&~foreground&~former_hand&(m>0)
    m[restore|preserve_cloth]=0
    w=m[:,:,None].astype(np.float32)/255
    # Source-over is inappropriate: the old crooked-arm silhouette must be
    # replaced, including its transparent surrounding pixels.
    blended=np.rint(old.astype(np.float32)*(1-w)+raw.astype(np.float32)*w).clip(0,255).astype(np.uint8)
    dest=out/name;save_png_verified(Image.fromarray(blended,'RGBA'),dest)
    save_png_verified(Image.fromarray(m,'L'),mask_dir/f'{f:03}_left_arm.png')
    records.append({'frame_asset':f,'source':str(source.relative_to(ROOT)),
       'source_sha256':sha(source),'repair_raw':str(repair.relative_to(ROOT)),
       'repair_raw_sha256':sha(repair),'output':str(dest.relative_to(ROOT)),
       'output_sha256':sha(dest),'canvas':[1024,1536],
       'registration':'identity; no translation, resize, warp or inbetween interpolation',
       'scope':'whole shoulder/armhole/upper-arm/elbow/forearm/bangle/wrist plus held cloth fold',
       'changed_pixels':int(np.any(blended!=old,axis=2).sum())})
(ROOT/'LEFT_ARM_COMPOSITE.json').write_text(json.dumps({'polygon':POLYGON,'records':records},ensure_ascii=False,indent=2)+'\n')
print('Composed',len(records),'registered cels from one generated complete-arm repair; no production files installed yet.')
