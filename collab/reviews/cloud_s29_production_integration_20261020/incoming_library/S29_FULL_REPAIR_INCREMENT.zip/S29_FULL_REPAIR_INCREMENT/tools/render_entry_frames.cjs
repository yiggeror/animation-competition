#!/usr/bin/env node
'use strict';
// Real S29 canvas capture through the repository's own server and dev/view.html.
// This runner does not alter scene content, timing, audio, or the EDL.
const fs = require('fs');
const path = require('path');
const { spawn, execFileSync } = require('child_process');
let chromium;
try { ({ chromium } = require('playwright')); }
catch { ({ chromium } = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'))); }
const args = {};
for (let i = 2; i < process.argv.length; i += 2) args[process.argv[i].replace(/^--/, '')] = process.argv[i + 1];
const repo = path.resolve(args.repo || '../s29_repo');
const out = path.resolve(args.out || 's29_preview');
const mod = args.mod || 'js/paint/shots/s29.js';
const first = Number(args.first ?? 240), last = Number(args.last ?? 271);
const expectedDuration = Number(args.duration ?? (10 + 32 / 24));
const chrome = args.chromium || process.env.CHROMIUM_PATH;
const W = 1920, H = 1080, FPS = 24;
const tag = f => String(f).padStart(3, '0');
const log = { status: 'starting', startedUTC: new Date().toISOString(), entry: mod,
  loader: 'dev/view.html', width: W, height: H, fps: FPS, firstFrame: first, lastFrame: last,
  audio: 'Video only; source audio and EDL untouched.', responses: [], requestsFailed: [],
  pageErrors: [], console: [], frames: [] };
const saveLog = () => fs.writeFileSync(path.join(out, 'EXECUTION_LOG.json'), JSON.stringify(log, null, 2) + '\n');
let browser, server, encoder, encoderDone, encoderError, encoderStderr = '';

(async () => {
  if (!Number.isInteger(first) || !Number.isInteger(last) || first < 0 || last >= Math.round(expectedDuration * FPS) || last < first)
    throw Error('Use integer frames within the candidate S29 duration.');
  if (!chrome || !fs.existsSync(chrome)) throw Error('Provide a real Chromium executable using --chromium.');
  if (fs.existsSync(out)) throw Error('Output already exists; choose a new --out directory.');
  fs.mkdirSync(path.join(out, 'frames'), { recursive: true });
  try {
    log.commitRead = execFileSync('git', ['-C', repo, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
    log.workingChanges = execFileSync('git', ['-C', repo, 'status', '--porcelain'], { encoding: 'utf8' }).trim();
    server = await require(path.join(repo, 'tools/js/serve.cjs')).start(0);
    browser = await chromium.launch({ executablePath: chrome, headless: true,
      args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
    log.browser = { version: browser.version(), executable: chrome };
    const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
    page.setDefaultTimeout(180000); page.setDefaultNavigationTimeout(180000);
    page.on('response', r => log.responses.push({ url: r.url(), status: r.status() }));
    page.on('requestfailed', r => log.requestsFailed.push({ url: r.url(), error: r.failure()?.errorText }));
    page.on('pageerror', e => log.pageErrors.push(String(e.stack || e)));
    page.on('console', m => log.console.push({ type: m.type(), text: m.text(), location: m.location() }));
    page.on('crash', () => log.pageErrors.push('Page crashed.'));
    const bad = () => log.pageErrors.length || log.requestsFailed.length || encoderError ||
      log.responses.some(r => r.status >= 400 && !new URL(r.url).pathname.endsWith('/favicon.ico')) ||
      log.console.some(m => m.type === 'error' && !m.location.url?.endsWith('/favicon.ico'));
    const check = () => { if (bad()) throw Error('Browser/resource/encoder error; see EXECUTION_LOG.json.'); };
    log.url = 'http://127.0.0.1:' + server.address().port + '/dev/view.html?' +
      new URLSearchParams({ mod, w: String(W), h: String(H) });
    await page.goto(log.url);
    await page.waitForFunction(() => window.__ready === true || window.__error);
    log.loaderState = await page.evaluate(() => ({ ready: window.__ready, error: window.__error,
      duration: window.DURATION, canvas: [document.getElementById('c').width, document.getElementById('c').height],
      fonts: document.fonts.status }));
    if (log.loaderState.error) throw Error(log.loaderState.error);
    if (Math.abs(log.loaderState.duration - expectedDuration) > 1e-9) throw Error('S29 duration does not match requested candidate duration.');
    check();
    const video = `S29_F${tag(first)}_F${tag(last)}.mp4`;
    const partial = path.join(out, video.replace('.mp4', '.partial.mp4'));
    log.encoderArgs = ['-y', '-v', 'error', '-f', 'image2pipe', '-vcodec', 'png', '-framerate', String(FPS),
      '-i', 'pipe:0', '-an', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart', partial];
    encoder = spawn('ffmpeg', log.encoderArgs, { stdio: ['pipe', 'ignore', 'pipe'] });
    encoder.stderr.on('data', b => { encoderStderr += b; });
    encoder.on('error', e => { encoderError = String(e); });
    encoder.stdin.on('error', e => { encoderError = String(e); });
    encoderDone = new Promise(resolve => encoder.on('close', resolve));
    log.status = 'rendering';
    for (let frame = first; frame <= last; frame++) {
      const started = Date.now();
      await page.evaluate(t => window.renderFrame(t), frame / FPS);
      check();
      const png = await page.locator('#c').screenshot({ type: 'png' });
      const name = `frames/F${tag(frame)}.png`;
      fs.writeFileSync(path.join(out, name), png);
      if (!encoder.stdin.write(png)) await new Promise((resolve, reject) => {
        const drain = () => { encoder.stdin.off('error', error); resolve(); };
        const error = e => { encoder.stdin.off('drain', drain); reject(e); };
        encoder.stdin.once('drain', drain); encoder.stdin.once('error', error);
      });
      log.frames.push({ frame, t: frame / FPS, png: name, bytes: png.length, milliseconds: Date.now() - started });
      if (frame === first || frame % 12 === 0 || frame === last) {
        saveLog(); console.log(`S29 actual entry F${tag(frame)} / F${tag(last)} (${log.frames.at(-1).milliseconds} ms)`);
      }
    }
    encoder.stdin.end();
    const code = await encoderDone;
    if (code !== 0) throw Error(`FFmpeg exit ${code}: ${encoderStderr}`);
    check();
    log.probe = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', partial], { encoding: 'utf8' }));
    const stream = log.probe.streams[0];
    if (log.probe.streams.length !== 1 || stream.width !== W || stream.height !== H ||
        stream.r_frame_rate !== '24/1' || Number(stream.nb_frames) !== last - first + 1)
      throw Error('Encoded video dimensions/frame count/frame rate mismatch.');
    execFileSync('ffmpeg', ['-v', 'error', '-xerror', '-i', partial, '-f', 'null', '-'], { stdio: ['ignore', 'ignore', 'pipe'] });
    fs.renameSync(partial, path.join(out, video));
    log.video = video; log.status = 'completed'; log.completedUTC = new Date().toISOString(); saveLog();
    console.log(`Saved ${video}: ${last - first + 1} frames, ${(last - first + 1) / FPS}s, 1920×1080, 24fps.`);
  } catch (e) {
    log.status = 'failed'; log.failure = String(e.stack || e); process.exitCode = 1;
    console.error(log.failure);
  } finally {
    saveLog();
    if (encoder && encoder.exitCode === null && !encoder.killed) encoder.kill('SIGTERM');
    if (browser) await browser.close();
    if (server) await new Promise(resolve => server.close(resolve));
    saveLog();
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
