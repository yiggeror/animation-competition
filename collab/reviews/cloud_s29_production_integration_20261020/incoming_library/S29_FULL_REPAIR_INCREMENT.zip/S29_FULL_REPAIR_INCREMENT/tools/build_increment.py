#!/usr/bin/env python3
"""List or package the S29 production delta against this turn's saved baseline.

Without --build this only lists the selected scope. No production file is
modified. The MP4 is fingerprinted when supplied, but never put in the ZIP.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CELS = (0, 24, 57, 75, 78, 81, 84, 90, 93, 96, 99, 102, 108, 120, 123, 126)
ARM_CELS = (75, 78, 81, 84, 90, 93, 96, 99, 102, 108, 120)
TROUSER_CELS = (90, 93, 96, 99, 102, 108, 120, 123, 126)
RAW_PROMPTS = {
    'left_arm_master_v1.png': 'LEFT_ARM_MASTER.txt',
    'F057_v1.png': 'F057.txt',
    'F075_v2.png': 'F075_v2.txt',
    'F123_v1.png': 'F123.txt',
    'F126_v2.png': 'F126_v2.txt',
}
TOOLS = (
    'compose_left_arm.py', 'compose_lowering_hand.py',
    'compose_lift_inbetweens.py', 'repair_trouser_join.py',
    'render_entry_frames.cjs', 'play_complete_video.cjs', 'build_increment.py',
)
RECORDS = (
    'BASELINE.json', 'SOURCE_VERSION.json', 'LATEST_TEAM_INPUT_CHECK.json',
    'ADOPTED_ASSETS.json', 'LEFT_ARM_COMPOSITE.json',
    'LOWERING_HAND_COMPOSITE.json', 'LIFT_INBETWEEN_COMPOSITE.json',
    'EXPOSURE.json',
)
ACTUAL_RECORDS = ('ENTRY_RENDER_SUMMARY.json', 'FRAME_PROVENANCE.json',
                  'VIDEO_VALIDATION.json', 'RETAINED_FILES_CHECK.json')
ASSET_DIRS = ('assets/chars/s29', 'assets/chars/s29_tail', 'assets/chars/s29_prepare')
SHARED_S29_ASSETS = tuple('assets/chars/g29_prepare_blow' + suffix + '.png'
                         for suffix in ('', '_n', '_m', '_shadow'))
SHOT_CODE = ('js/paint/shots/s29.js', 'js/paint/shots/s29_lamp.js',
             'js/paint/shots/s29_preparation_drawn.js')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def in_scope(name):
    return (any(name.startswith(d + '/') for d in ASSET_DIRS)
            or name.startswith('js/anim/s29/')
            or name in SHARED_S29_ASSETS or name in SHOT_CODE)


def production_delta(repo, baseline):
    candidates = {name for name in baseline if in_scope(name)}
    for directory in (*ASSET_DIRS, 'js/anim/s29'):
        candidates.update(p.relative_to(repo).as_posix()
                          for p in (repo / directory).rglob('*') if p.is_file())
    candidates.update(name for name in SHOT_CODE if (repo / name).is_file())
    changes, patch = [], []
    for name in sorted(candidates):
        before = baseline.get(name)
        current = repo / name
        payload = current.read_bytes() if current.is_file() else None
        current_sha = digest(payload) if payload is not None else None
        if current_sha == (before or {}).get('sha256'):
            continue
        if payload is None:
            raise ValueError('This production delta unexpectedly deletes a file: ' + name)
        kind = 'png' if current.suffix == '.png' else 'code'
        if kind == 'code' and current.suffix != '.js':
            raise ValueError('Unexpected S29 production file type: ' + name)
        changes.append({'path': name, 'kind': kind,
                        'change': 'modified' if before else 'added',
                        'baseline_sha256': (before or {}).get('sha256'),
                        'sha256': current_sha, 'bytes': len(payload)})
        if kind == 'code':
            old_path = ROOT / 'baseline' / name
            old = old_path.read_bytes() if before else b''
            if before and digest(old) != before['sha256']:
                raise ValueError('Saved baseline and BASELINE.json disagree: ' + name)
            patch.append(f'diff --git a/{name} b/{name}\n')
            patch.extend(difflib.unified_diff(
                old.decode('utf-8').splitlines(keepends=True),
                payload.decode('utf-8').splitlines(keepends=True),
                fromfile='a/' + name if before else '/dev/null',
                tofile='b/' + name, n=3))
    return changes, ''.join(patch).encode('utf-8')


def compact_run(path):
    raw = path.read_bytes()
    record = json.loads(raw)
    result = {'source_log': path.name, 'source_log_sha256': digest(raw)}
    for key in ('status', 'startedUTC', 'completedUTC', 'entry', 'loader',
                'width', 'height', 'fps', 'firstFrame', 'lastFrame', 'browser',
                'commitRead', 'loaderState', 'failure', 'error', 'audio'):
        if key in record:
            result[key] = record[key]
    if 'frames' in record:
        result['rendered_frame_count'] = len(record['frames'])
    for key in ('pageErrors', 'requestsFailed', 'requestFailures', 'consoleErrors'):
        if key in record:
            result[key] = record[key]
    result['console_errors'] = [x for x in record.get('console', [])
                                if x.get('type') == 'error']
    result['http_errors'] = [x for x in record.get('responses', [])
                             if x.get('status', 0) >= 400]
    if 'probe' in record:
        result['encoded_streams'] = [
            {k: stream[k] for k in ('codec_type', 'codec_name', 'width', 'height',
                                     'r_frame_rate', 'nb_frames', 'duration') if k in stream}
            for stream in record['probe'].get('streams', [])]
    if 'media' in record:
        result['playback'] = {k: v for k, v in record['media'].items()
                              if k != 'frameCallbacks'}
        result['playback']['frame_callback_count'] = len(record['media'].get('frameCallbacks', []))
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo', type=Path, default=ROOT.parent / 's29_repo')
    ap.add_argument('--build', action='store_true', help='Write the final ZIP after review')
    ap.add_argument('--output', type=Path, default=ROOT / 'S29_FULL_REPAIR_INCREMENT.zip')
    ap.add_argument('--readme', type=Path, default=ROOT / 'PACKAGE_README_DRAFT.md')
    ap.add_argument('--exposure', type=Path, default=ROOT / 'EXPOSURE.csv')
    ap.add_argument('--trouser-dir', type=Path, default=ROOT / 'diagnostics/support_final')
    ap.add_argument('--video', type=Path, help='Final standalone MP4: fingerprint only, never zipped')
    ap.add_argument('--record', type=Path, action='append', default=[],
                    help='Final short factual review/production record (.md/.json/.txt)')
    ap.add_argument('--run-log', type=Path, action='append', default=[],
                    help='Actual entry/playback log; store a compact summary, not frames or video')
    args = ap.parse_args()
    repo = args.repo.resolve()
    baseline = json.loads((ROOT / 'BASELINE.json').read_text())
    changes, patch = production_delta(repo, baseline)
    members = {'changes.patch': patch}

    def add(source, target=None):
        source = Path(source)
        target = target or source.relative_to(ROOT).as_posix()
        if target in members:
            if members[target] == source:
                return
            raise ValueError('Duplicate package path: ' + target)
        if source.suffix.lower() in ('.mp4', '.mov', '.zip'):
            raise ValueError('Video/archive does not belong in the production increment: ' + str(source))
        members[target] = source

    for item in changes:
        if item['kind'] == 'png':
            add(repo / item['path'], 'production/' + item['path'])
    for raw, prompt in RAW_PROMPTS.items():
        add(ROOT / 'raw' / raw)
        add(ROOT / 'prompts' / prompt)
    for tool in TOOLS:
        add(ROOT / 'tools' / tool)
    for name in RECORDS:
        add(ROOT / name)
    for name in ACTUAL_RECORDS:
        add(ROOT / name, 'records/' + name)
    for frame in ARM_CELS:
        add(ROOT / 'masks' / f'{frame:03}_left_arm.png')
    add(ROOT / 'masks/F057_lowering_hand.png')
    for frame in (123, 126):
        for suffix in ('adoption', 'foreground', 'original_props', 'hand_priority',
                       'generated_prop_cleanup', 'local_fabric_texture_cleanup'):
            add(ROOT / 'masks/lift_inbetweens' / f'F{frame}_{suffix}.png')
    for frame in TROUSER_CELS:
        add(args.trouser_dir / 'masks' / f'F{frame:03}.png', f'masks/trouser/F{frame:03}.png')
    add(args.trouser_dir / 'REPAIR_MANIFEST.json', 'records/TROUSER_JOIN.json')
    add(args.exposure, 'EXPOSURE.csv')
    add(args.readme, 'README.md')
    for path in args.record:
        if path.suffix.lower() not in ('.md', '.json', '.txt'):
            raise ValueError('A short review record must be text or JSON: ' + str(path))
        add(path, 'records/' + path.name)
    if args.run_log:
        members['records/ACTUAL_RUNS.json'] = json_bytes([compact_run(p) for p in args.run_log])

    missing = [str(source) for source in members.values()
               if isinstance(source, Path) and not source.is_file()]
    pngs = [x for x in changes if x['kind'] == 'png']
    expected = {f'assets/chars/s29/F{frame:03}.png' for frame in CELS}
    actual = {x['path'] for x in pngs}
    summary = {'mode': 'build' if args.build else 'list_only_no_zip_written',
               'baseline': 'This turn baseline/ + BASELINE.json; not git HEAD',
               'changed_production_files': changes,
               'selected_raw_count': len(RAW_PROMPTS), 'package_member_count': len(members) + 1,
               'missing_files': missing, 'missing_expected_cels': sorted(expected - actual),
               'other_changed_pngs': sorted(actual - expected),
               'independent_video': str(args.video) if args.video else None}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not args.build:
        return
    if missing:
        raise FileNotFoundError('Finish the missing deliverable files before packaging.')
    if expected != actual:
        raise ValueError('The final changed production PNG list differs from the reviewed 16 cels.')
    if not args.video or not args.video.is_file():
        raise FileNotFoundError('Supply the final independent MP4 using --video.')
    if args.output.exists():
        raise FileExistsError('Keep the existing package; choose a new --output filename.')
    approved = json.loads((ROOT / 'ADOPTED_ASSETS.json').read_text())
    for item in approved:
        if digest((repo / item['path']).read_bytes()) != item['sha256']:
            raise ValueError('Production PNG differs from final ADOPTED_ASSETS.json: ' + item['path'])

    payloads = {name: source.read_bytes() if isinstance(source, Path) else source
                for name, source in members.items()}
    readme = payloads['README.md'].decode('utf-8').replace('（交付说明草稿）', '')
    readme = readme.replace('<!-- FINAL_RECORD_STATUS -->',
                            '实际入口和原速播放的结果以 `records/` 内本次实际记录为准。')
    payloads['README.md'] = readme.encode('utf-8')
    video_data = args.video.read_bytes()
    manifest = {'baseline': 'baseline/ and BASELINE.json from the retained complete workcopy',
                'changed_production_files': changes,
                'new_action_cels': [57, 75, 123, 126],
                'full_arm_repair_sources': 1, 'existing_cels_using_full_arm_source': 10,
                'frames': 272, 'fps': 24, 'duration_seconds': 272 / 24,
                'video_is_independent': {'filename': args.video.name,
                                         'bytes': len(video_data), 'sha256': digest(video_data)},
                'files': {name: {'bytes': len(data), 'sha256': digest(data)}
                          for name, data in sorted(payloads.items())}}
    payloads['MANIFEST_SHA256.json'] = json_bytes(manifest)
    temporary = args.output.with_suffix('.writing.zip')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(payloads.items()):
            archive.writestr('S29_FULL_REPAIR_INCREMENT/' + name, data)
    with zipfile.ZipFile(temporary) as archive:
        bad = archive.testzip()
        if bad:
            raise OSError('ZIP member failed CRC: ' + bad)
    temporary.replace(args.output)
    print(json.dumps({'output': str(args.output), 'bytes': args.output.stat().st_size,
                      'sha256': digest(args.output.read_bytes()),
                      'members': len(payloads), 'video_in_zip': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
