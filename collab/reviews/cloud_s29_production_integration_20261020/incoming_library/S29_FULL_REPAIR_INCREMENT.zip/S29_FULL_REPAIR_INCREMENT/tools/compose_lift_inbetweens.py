#!/usr/bin/env python3
"""Adopt two drawn S29 lift inbetweens without moving the puppets or support.

New arms and actual drawn cloth folds come from raw F123_v1 / F126_v2.
The repaired F120 supplies the body; the team input F120 supplies original
puppets and rods at identical source coordinates. Only the two adopted
PNGs and their masks/manifest are written, never production assets.
"""
from pathlib import Path
import hashlib
import json
import io
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import binary_dilation, binary_closing, binary_fill_holes, gaussian_filter, distance_transform_edt

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'adopted/F120.png'
PROPS=ROOT/'input_front/assets/chars/s29/F120.png'
W,H=1024,1536

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def poly(points, blur=0):
    im=Image.new('L',(W*4,H*4),0)
    ImageDraw.Draw(im).polygon([(x*4,y*4) for x,y in points],fill=255)
    im=im.resize((W,H),Image.Resampling.LANCZOS)
    return np.array(im.filter(ImageFilter.GaussianBlur(blur)) if blur else im)

NEAR_ARM=[(177,555),(330,550),(367,609),(446,646),(529,675),
          (590,695),(612,845),(524,865),(432,814),(347,774),
          (239,729),(188,679)]
FAR_ARM=[(501,421),(564,411),(625,462),(660,531),(720,593),
         (765,659),(763,807),(689,814),(608,765),(532,721),
         (489,681),(490,580),(505,531)]
CLOTH=[(486,699),(594,704),(678,703),(810,717),(884,735),
       (953,775),(1023,824),(1023,969),(990,1079),(876,1101),
       (798,1057),(685,1048),(617,997),(568,1008),(542,1114),
       (464,1114),(416,1049),(432,970),(404,953),(344,936),
       (262,949),(227,915),(245,850),(307,826),(361,789),
       (411,760),(455,737)]

# Hand/forearm silhouettes are the last foreground layer; this prevents
# restoring an old hand beneath the original prop pixels at the old pinch.
NEAR_PRIORITY={
    'F123':[(199,565),(318,565),(331,610),(364,637),(430,666),
            (476,696),(514,710),(540,716),(555,725),(554,736),
            (544,741),(552,746),(549,760),(534,773),(517,785),
            (500,784),(479,776),(464,763),(448,749),(431,735),
            (350,716),(267,691),(225,658),(208,615)],
    'F126':[(199,565),(318,565),(332,610),(372,633),(437,661),
            (474,672),(520,681),(547,687),(563,697),(561,708),
            (550,712),(556,723),(550,736),(534,745),(517,750),
            (495,748),(476,739),(459,725),(441,711),(352,704),
            (267,683),(225,654),(208,613)],
}
FAR_PRIORITY=[(624,635),(672,634),(701,654),(712,679),(733,704),
              (736,723),(726,746),(711,758),(691,760),(675,751),
              (668,741),(660,748),(648,747),(642,717),(632,684)]

# Manual anatomical exclusions prevent ochre edge ink on the old fingers
# from being mistaken for the crane or its rods.
OLD_NEAR=[(180,553),(326,551),(333,621),(356,651),(449,706),
          (481,737),(519,753),(546,763),(565,772),(568,783),
          (558,790),(565,798),(555,814),(539,825),(518,831),
          (498,828),(480,820),(467,805),(449,787),(424,776),
          (337,749),(251,714),(223,680),(205,632)]
OLD_FAR=[(625,628),(748,628),(748,776),(625,776)]


# The actual two edges of the raised front flap, read from the raw drawings.
# The right edge progressively passes in front of the crane leg and rods.
FOREGROUND={}
FOREGROUND['F123']=[(550,740),(563,774),(591,807),(619,835),
    (640,858),(663,881),(695,907),(727,927),(765,948),
    (824,978),(887,1010),(949,1055),(1010,1080),(1010,1130),
    (220,1130),(241,920),(293,907),(350,897),(408,881),
    (455,862),(481,838),(505,806),(528,772)]
FOREGROUND['F126']=[(553,705),(574,741),(606,762),(646,773),
    (707,772),(686,793),(653,807),(675,843),(713,877),
    (749,920),(812,952),(879,984),(949,1020),(1010,1070),
    (1010,1130),(213,1130),(245,908),(273,881),(365,835),
    (377,817),(380,793),(421,766),(480,740),(522,715)]

# The late generator returned a broad translucent halo. These silhouettes
# trace its actual inked outer contours; the halo is never composited.
FAR_SILHOUETTE=[(491,372),(533,372),(553,399),(574,434),
    (594,475),(605,503),(588,518),(599,561),(615,589),
    (638,615),(651,634),(676,632),(692,637),(704,650),
    (707,665),(724,682),(733,695),(736,713),(732,728),
    (720,743),(706,753),(696,756),(685,751),(671,741),
    (662,747),(651,746),(648,726),(634,707),(627,696),
    (597,686),(570,670),(549,650),(531,626),(521,597),
    (514,568),(493,574),(479,527),(476,433)]
CLOTH_SILHOUETTE=[(549,701),(608,699),(652,707),(694,712),
    (731,724),(776,733),(818,744),(855,761),(894,781),
    (932,805),(962,824),(981,845),(991,866),(988,886),
    (978,908),(988,925),(989,945),(985,960),(978,977),
    (970,992),(960,1008),(951,1021),(947,1027),(941,1027),
    (935,1023),(930,1017),(927,1012),(922,1018),(913,1027),
    (904,1037),(897,1043),(891,1040),(882,1031),(872,1020),
    (860,1009),(847,1003),(834,1000),(822,997),(817,991),
    (797,997),(770,989),(732,980),(698,970),(668,956),
    (634,946),(610,931),(589,916),(570,938),(555,975),
    (535,1008),(507,1031),(485,1018),(474,991),(477,961),
    (463,949),(439,937),(411,927),(362,925),(321,927),
    (293,920),(269,906),(252,889),(269,879),(313,856),
    (360,826),(407,787),(460,751),(511,720)]

BASE_TURTLE=[(271,869),(286,854),(322,840),(362,835),(400,835),
    (437,845),(458,861),(474,866),(486,861),(504,871),(501,881),
    (490,890),(478,885),(466,895),(440,901),(434,884),(407,882),
    (372,887),(364,902),(341,902),(334,884),(307,884),(304,893),
    (285,890),(283,880),(269,876)]
BASE_CRANE_BODY=[(493,741),(522,736),(546,739),(570,752),
    (598,767),(625,775),(664,779),(704,780),(733,774),
    (731,783),(708,791),(668,796),(628,800),(593,800),
    (564,791),(556,780),(564,770),(544,761),(525,753),(499,752)]
RAW_TURTLE={
'F123':[(271,870),(287,853),(322,840),(359,834),(397,838),
    (435,849),(472,865),(457,875),(427,883),(404,888),(366,890),
    (364,902),(343,905),(333,887),(301,886),(283,881),(271,877)],
'F126':[(272,879),(286,866),(308,853),(337,842),(371,832),
    (361,845),(336,861),(312,874),(289,883),(275,884)]}
RAW_CRANE={
'F123':[(548,729),(560,726),(581,737),(606,759),(637,775),
    (674,775),(716,768),(729,770),(713,783),(671,792),
    (642,793),(640,853),(625,859),(623,793),(610,794),
    (580,782),(567,766),(550,747)],
'F126':[(550,707),(571,714),(590,736),(616,752),(652,766),
    (701,761),(710,765),(695,774),(646,776),(605,769),
    (584,752),(561,729)]}

old_anatomy=(np.maximum(poly(OLD_NEAR),poly(OLD_FAR))>8)

def prop_mask(a, anatomical_exclusion):
    rgb=a[:,:,:3].astype(np.int16)
    y,x=np.indices(a.shape[:2])
    region=(((x>265)&(x<750)&(y>700)&(y<909))|
            ((x>550)&(x<1005)&(y>780)&(y<990)))
    gold=(rgb[:,:,0]>55)&(rgb[:,:,0]<215)&(rgb[:,:,0]>rgb[:,:,1]+18)&(rgb[:,:,1]>rgb[:,:,2]+12)&(rgb[:,:,2]<110)
    green=(rgb[:,:,1]>rgb[:,:,0]+5)&(rgb[:,:,1]>rgb[:,:,2]+5)&(y>820)&(x<550)
    red=(rgb[:,:,0]>rgb[:,:,1]+25)&(rgb[:,:,1]>rgb[:,:,2]+5)&(rgb[:,:,2]<75)&(x>375)&(x<420)&(y>775)&(y<825)
    m=(gold|green|red)&region&(a[:,:,3]>160)&(~anatomical_exclusion)
    m=binary_dilation(m,iterations=2)&(~anatomical_exclusion)
    # Dark crane ink is admitted only if the source pixel is actually dark,
    # never by a blanket rectangle that would classify blue cloth as a leg.
    shaft=(poly([(618,790),(642,790),(639,870),(650,881),
                  (615,884),(618,865)])>128)
    dark=(rgb[:,:,0]<70)&(rgb[:,:,1]<65)&(rgb[:,:,2]<58)&(a[:,:,3]>160)
    m|=shaft&dark&(~anatomical_exclusion)
    return m

def atomic_png(array, dest):
    im=Image.fromarray(array)
    stream=io.BytesIO(); im.save(stream,format='PNG')
    blob=stream.getvalue()
    check=Image.open(io.BytesIO(blob)); check.load()
    assert check.size==(W,H)
    temp=dest.with_name(dest.name+'.tmp')
    with temp.open('wb') as f:
        f.write(blob); f.flush(); os.fsync(f.fileno())
    os.replace(temp,dest)
    saved=Image.open(dest); saved.load()
    assert saved.tobytes()==im.tobytes()

base_blob=BASE.read_bytes()
base=np.array(Image.open(io.BytesIO(base_blob)).convert('RGBA'))
base_sha=hashlib.sha256(base_blob).hexdigest()
assert base.shape==(H,W,4)
prop_source=np.array(Image.open(PROPS).convert('RGBA'))
input_anatomy=old_anatomy|(poly([(583,630),(641,625),(686,659),(703,692),(702,719),(689,739),(678,751),(665,765),(649,766),(640,757),(630,749),(621,754),(609,751),(605,731),(596,713),(588,680)])>8)
base_props=prop_mask(prop_source,input_anatomy)
source_y,source_x=np.indices((H,W))
base_props&=source_y>=735
base_props|=(poly(BASE_TURTLE)>128)&(~old_anatomy)
base_props|=(poly(BASE_CRANE_BODY)>8)&(~input_anatomy)
base_props=binary_fill_holes(base_props)
old_prop_domain=base_props|(poly(BASE_CRANE_BODY)>8)|(poly(BASE_TURTLE)>8)
adoption=np.maximum.reduce([poly(NEAR_ARM,.7),poly(FAR_ARM,.7),poly(CLOTH,.7)])
outdir=ROOT/'adopted'; maskdir=ROOT/'masks/lift_inbetweens'
maskdir.mkdir(parents=True,exist_ok=True)
records=[]
for name,rawfile in [('F123','F123_v1.png'),('F126','F126_v2.png')]:
    source=ROOT/'raw'/rawfile
    raw=np.array(Image.open(source).convert('RGBA'))
    assert raw.shape==base.shape
    priority=np.maximum(poly(NEAR_PRIORITY[name],.4),poly(FAR_PRIORITY,.4))
    raw_props=prop_mask(raw,priority>8)
    raw_props|=((poly(RAW_TURTLE[name])>8)|(poly(RAW_CRANE[name])>8))&(priority<8)
    raw_props=binary_dilation(binary_fill_holes(raw_props),iterations=1)&(priority<8)
    foreground=poly(FOREGROUND[name])>128
    restore=base_props&(~foreground)&(priority<8)
    if name=='F126':
        yy,xx=np.indices((H,W))
        crane_top=(xx>375)&(xx<750)&(yy<800)&(yy>700)
        restore&=(~crane_top)|(poly(RAW_CRANE[name])>128)
    # Remove generated alterations with the matching original background.
    # At the old pinch footprint where that would resurrect an old
    # finger, repair only the texture of the same already-drawn fabric.
    erase=raw_props&(~restore)&(priority<8)
    texture_holes=erase&(old_anatomy|(base[:,:,3]<120)|(old_prop_domain&(~restore)))
    texture_holes=binary_dilation(binary_closing(texture_holes,iterations=2),iterations=1)&(priority<8)
    erase|=texture_holes
    if texture_holes.any():
        rgb=raw[:,:,:3].astype(np.int16)
        cloth=(rgb[:,:,2]>rgb[:,:,0]+16)&(rgb[:,:,2]>rgb[:,:,1]+6)&(raw[:,:,3]>160)&(~raw_props)&(priority<8)
        weights=gaussian_filter(cloth.astype(float),sigma=6)
        colour=np.stack([gaussian_filter(raw[:,:,c].astype(float)*cloth,sigma=6)/np.maximum(weights,1e-8) for c in range(3)],axis=2)
        _,nearest=distance_transform_edt(~cloth,return_indices=True)
        too_far=weights<1e-5
        colour[too_far]=raw[nearest[0][too_far],nearest[1][too_far],:3]
        raw[texture_holes,:3]=np.rint(colour[texture_holes]).clip(0,255).astype(np.uint8)

    w=adoption[:,:,None].astype(np.float32)/255
    result=np.rint(base.astype(np.float32)*(1-w)+raw.astype(np.float32)*w).clip(0,255).astype(np.uint8)
    result[erase&(~texture_holes)]=base[erase&(~texture_holes)]
    result[restore]=prop_source[restore]
    k=priority[:,:,None].astype(np.float32)/255
    result=np.rint(result.astype(np.float32)*(1-k)+raw.astype(np.float32)*k).clip(0,255).astype(np.uint8)
    if name=='F126':
        # Preserve source support/body alpha and admit actual newly drawn arm
        # and cloth contours. Only clear the generator halo outside them.
        matte=np.maximum.reduce([poly(FAR_SILHOUETTE),poly(CLOTH_SILHOUETTE),priority])
        yy,xx=np.indices((H,W))
        background_zone=((xx>550)&(yy<717))|((xx>730)&(yy<823))|((xx>860)&(yy<1050))
        affected=(adoption>0)&(background_zone|(base[:,:,3]<8))
        result[affected,3]=np.minimum(result[:,:,3],matte)[affected]
        # The old mother alpha is not a valid cutout for the newly exposed
        # hem. Preserve its real cloth ink and the visible trouser edge;
        # remove the generator haze between them, with no rectangular clip.
        trouser_edge=poly([(0,940),(807,940),(816,988),(819,1001),
            (822,1016),(827,1036),(833,1060),(838,1087),
            (839,1116),(0,1116)])
        hem_matte=np.maximum(poly(CLOTH_SILHOUETTE),trouser_edge)
        hem_zone=(xx>=807)&(xx<=1023)&(yy>=985)&(yy<=1049)&(adoption>0)
        result[hem_zone,3]=np.minimum(raw[:,:,3],hem_matte)[hem_zone]

    dest=outdir/(name+'.png')
    atomic_png(result,dest)
    for label,m in [('adoption',adoption),('foreground',(foreground*255).astype(np.uint8)),
        ('original_props',(restore*255).astype(np.uint8)),('hand_priority',priority),
        ('generated_prop_cleanup',(erase*255).astype(np.uint8)),
        ('local_fabric_texture_cleanup',(texture_holes*255).astype(np.uint8))]:
        atomic_png(m,maskdir/(name+'_'+label+'.png'))
    records.append({'output':str(dest.relative_to(ROOT)),'sha256':sha(dest),
        'raw':str(source.relative_to(ROOT)),'raw_sha256':sha(source),
        'mother':str(BASE.relative_to(ROOT)),'mother_sha256':base_sha,
        'original_puppets_and_rods':str(PROPS.relative_to(ROOT)),'original_props_sha256':sha(PROPS),
        'registration':'identity: no source rescale, translation, mesh, or interpolation',
        'raw_adoption_polygon_names':['NEAR_ARM','FAR_ARM','CLOTH'],
        'foreground_cloth_polygon':FOREGROUND[name],
        'original_visible_prop_pixels':int(restore.sum()),
        'local_fabric_texture_cleanup_pixels':int(texture_holes.sum()),
        'png_validated_by':'full decoded pixel equality after atomic write'})
(ROOT/'LIFT_INBETWEEN_COMPOSITE.json').write_text(json.dumps({'records':records},ensure_ascii=False,indent=2)+'\n')
print('Wrote adopted F123/F126 and their local adoption/occlusion masks; no production files changed.')
