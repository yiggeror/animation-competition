#!/usr/bin/env node
'use strict';
// One uninterrupted 1x HTML5 playback of the completed candidate.
// Frame callbacks establish playback; visual judgement uses the actual scene cels.
const fs=require('fs'),path=require('path'),http=require('http');
let chromium;
try { ({chromium}=require('playwright')); }
catch { ({chromium}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright'))); }
const args={};for(let i=2;i<process.argv.length;i+=2)args[process.argv[i].replace(/^--/,'')]=process.argv[i+1];
const file=path.resolve(args.video),out=path.resolve(args.out),size=fs.statSync(file).size;
const log={file,startedUTC:new Date().toISOString(),consoleErrors:[],pageErrors:[],requestFailures:[]};
let browser,server;
const save=()=>fs.writeFileSync(out,JSON.stringify(log,null,2)+'\n');
(async()=>{try{
  server=http.createServer((req,res)=>{
    if(req.url==='/video.mp4'){
      const range=req.headers.range;
      if(range){const m=/bytes=(\d+)-(\d*)/.exec(range),start=+m[1],end=m[2]?+m[2]:size-1;
        res.writeHead(206,{'Content-Type':'video/mp4','Content-Length':end-start+1,'Content-Range':`bytes ${start}-${end}/${size}`,'Accept-Ranges':'bytes'});
        fs.createReadStream(file,{start,end}).pipe(res);
      }else{res.writeHead(200,{'Content-Type':'video/mp4','Content-Length':size,'Accept-Ranges':'bytes'});fs.createReadStream(file).pipe(res);}return;
    }
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end(`<!doctype html><style>html,body{margin:0;background:#181818}video{display:block;width:1920px;height:1080px}</style>
      <video id="v" src="/video.mp4" muted playsinline></video><script>
      const v=document.getElementById('v');window.events=[];window.presented=[];
      for(const e of ['loadedmetadata','playing','waiting','stalled','ended','error','ratechange'])v.addEventListener(e,()=>events.push({event:e,time:v.currentTime,wall:performance.now()}));
      function frame(now,m){presented.push({mediaTime:m.mediaTime,wallTime:now,presentedFrames:m.presentedFrames});if(!v.ended)v.requestVideoFrameCallback(frame)}
      v.playbackRate=1;v.requestVideoFrameCallback(frame);v.play();</script>`);
  });await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:args.chromium,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']});
  log.browser=browser.version();const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
  page.on('console',m=>{if(m.type()==='error')log.consoleErrors.push(m.text())});
  page.on('pageerror',e=>log.pageErrors.push(String(e)));
  page.on('requestfailed',r=>log.requestFailures.push({url:r.url(),error:r.failure()?.errorText}));
  await page.goto('http://127.0.0.1:'+server.address().port+'/');
  await page.waitForFunction(()=>document.getElementById('v').ended||document.getElementById('v').error,{},{timeout:45000});
  log.media=await page.evaluate(()=>{const v=document.getElementById('v'),q=v.getVideoPlaybackQuality();return {
    ended:v.ended,currentTime:v.currentTime,duration:v.duration,playbackRate:v.playbackRate,
    videoWidth:v.videoWidth,videoHeight:v.videoHeight,readyState:v.readyState,
    error:v.error?{code:v.error.code,message:v.error.message}:null,
    quality:{totalVideoFrames:q.totalVideoFrames,droppedVideoFrames:q.droppedVideoFrames,corruptedVideoFrames:q.corruptedVideoFrames},
    events:window.events,frameCallbacks:window.presented};});
  await page.locator('#v').screenshot({path:out.replace(/\.json$/,'_LAST_FRAME.png')});
  log.status=log.media.ended&&log.media.playbackRate===1&&!log.media.error&&!log.consoleErrors.length&&!log.pageErrors.length&&!log.requestFailures.length?'completed':'failed';
  log.completedUTC=new Date().toISOString();save();
  console.log(JSON.stringify({status:log.status,browser:log.browser,duration:log.media.duration,playbackRate:log.media.playbackRate,ended:log.media.ended,quality:log.media.quality,frameCallbacks:log.media.frameCallbacks.length},null,2));
  if(log.status==='failed')process.exitCode=1;
}catch(e){log.status='failed';log.error=String(e.stack||e);save();console.error(log.error);process.exitCode=1;}
finally{save();if(browser)await browser.close();if(server)server.close();}})();
