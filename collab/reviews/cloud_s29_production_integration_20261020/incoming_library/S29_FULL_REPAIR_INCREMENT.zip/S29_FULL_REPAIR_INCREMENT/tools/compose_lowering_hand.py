#!/usr/bin/env python3
"""Adopt the drawn F057 descending palm between existing F054 and F060.
Keep original face, green-bangle grip, cloth, puppets, rods and seated support.
"""
from pathlib import Path
import hashlib, io, json, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'baseline/assets/chars/s29/F054.png'
RAW=ROOT/'raw/F057_v1.png'
POLYGON=[(176,341),(273,316),(331,343),(375,423),(453,510),
 (489,575),(532,617),(560,674),(543,705),(520,702),(536,736),
 (544,777),(528,787),(492,783),(453,770),(400,757),(338,752),
 (270,741),(217,730),(167,713),(120,700),(85,679),(88,570),
 (101,494),(140,411)]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(im,p):
 b=io.BytesIO();im.save(b,format='PNG');data=b.getvalue()
 Image.open(io.BytesIO(data)).load()
 q=p.with_suffix('.writing.png')
 with q.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 Image.open(q).load();assert q.read_bytes()==data;os.replace(q,p)

old=np.array(Image.open(SOURCE).convert('RGBA'))
raw=np.array(Image.open(RAW).convert('RGBA'))
assert old.shape==raw.shape==(1536,1024,4)
mask=Image.new('L',(4096,6144),0)
ImageDraw.Draw(mask).polygon([(4*x,4*y) for x,y in POLYGON],fill=255)
mask=mask.resize((1024,1536),Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(.7))
m=np.array(mask)
# Remove the former horizontal forearm's complete silhouette; the descending
# arm must not leave a sliver of the old elbow outside the new blouse contour.
oy,ox=np.indices(m.shape);org=old[:,:,:3].astype(np.int16)
old_skin=(org[:,:,0]>175)&(org[:,:,0]>org[:,:,1]+20)&(org[:,:,1]>org[:,:,2]+20)
old_skin&=(ox>70)&(ox<550)&(oy>550)&(oy<720)&(old[:,:,3]>128)
clear=Image.fromarray((old_skin*255).astype(np.uint8),'L').filter(ImageFilter.MaxFilter(7))
m=np.maximum(m,np.array(clear))
# The palm is foreground. No raw puppet ink is adopted outside its drawn skin.
y,x=np.indices(m.shape)
rgb=raw[:,:,:3].astype(np.int16)
gold=(rgb[:,:,0]<215)&(rgb[:,:,0]>55)&(rgb[:,:,0]>rgb[:,:,1]+18)&(rgb[:,:,1]>rgb[:,:,2]+12)&(rgb[:,:,2]<110)
m[gold&(y>730)]=0
w=m[:,:,None].astype(np.float32)/255
out=np.rint(old.astype(np.float32)*(1-w)+raw.astype(np.float32)*w).clip(0,255).astype(np.uint8)
dest=ROOT/'adopted/F057.png';save(Image.fromarray(out,'RGBA'),dest)
save(Image.fromarray(m,'L'),ROOT/'masks/F057_lowering_hand.png')
(ROOT/'LOWERING_HAND_COMPOSITE.json').write_text(json.dumps({
 'source':str(SOURCE.relative_to(ROOT)),'source_sha256':sha(SOURCE),
 'raw':str(RAW.relative_to(ROOT)),'raw_sha256':sha(RAW),
 'adopted':str(dest.relative_to(ROOT)),'sha256':sha(dest),
 'registration':'identity; a drawn intermediate, no limb transform or image interpolation',
 'polygon':POLYGON},ensure_ascii=False,indent=2)+'\n')
print('Saved F057 drawn descending hand, with unchanged original seated support and props.')
