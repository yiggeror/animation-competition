#!/usr/bin/env python3
"""Repair the S29 far-trouser cut/paste seam without moving the character.

Default output is diagnostics/support_fixed, never adopted or production.
Only a small exposed trouser patch above source y=1100 is restored from the
registered F078 cel. Current cloth/puppets/rods, hips, seat, shoes and stool
are outside the edit. The callable repair_trouser_join() returns RGBA + mask.
"""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
IDS = (90, 93, 96, 99, 102, 108, 120)
# Lower edge of the CURRENT flower cloth, traced in registered source pixels.
# The repair remains below these points, including the dangling far cloth tip.
RIMS = {
    90: [(662,958),(681,972),(704,982),(721,990),(739,1000),
         (750,1003),(767,996),(786,996),(809,998),(846,999),(868,1020)],
    93: [(662,958),(681,972),(704,982),(721,990),(739,1000),
         (750,1003),(767,996),(786,996),(809,998),(846,999),(868,1020)],
    96: [(662,957),(680,970),(701,983),(721,995),(740,1003),
         (752,1007),(767,1001),(788,999),(811,1000),(846,1000),(868,1021)],
    99: [(662,959),(680,972),(701,985),(721,997),(741,1006),
         (752,1009),(768,1003),(790,1000),(812,1002),(846,1001),(868,1022)],
    102:[(662,959),(680,972),(701,985),(721,997),(741,1006),
         (752,1009),(768,1003),(790,1000),(812,1002),(846,1001),(868,1022)],
    108:[(662,967),(680,981),(700,993),(720,1005),(741,1014),
         (752,1018),(769,1012),(792,1010),(813,1013),(842,1013),(868,1027)],
    120:[(662,967),(680,981),(700,993),(720,1005),(741,1014),
         (752,1018),(769,1012),(792,1010),(813,1013),(842,1013),(868,1027)],
    123:[(662,947),(680,960),(700,974),(720,987),(740,994),
         (752,994),(770,991),(791,987),(809,988),(818,995),
         (835,1004),(850,1009),(868,1021)],
    126:[(662,947),(680,961),(700,974),(720,985),(740,990),
         (752,990),(771,986),(792,981),(809,987),(818,994),
         (835,1003),(850,1009),(858,1017),(868,1021)],
}


def aa_polygon(points, size=(1024, 1536), scale=4):
    im = Image.new('L', (size[0]*scale, size[1]*scale), 0)
    ImageDraw.Draw(im).polygon([(round(x*scale),round(y*scale)) for x,y in points], fill=255)
    return np.asarray(im.resize(size, Image.Resampling.LANCZOS), dtype=np.float32)/255


def repair_trouser_join(current, donor, frame, edge_donor=None):
    """Return (repaired_RGBA, semantic_mask_L) for one known registered cel.

    Inputs are PIL images in the original 1024 x 1536 canvas. There is
    no image resize, registration transform, animation interpolation or new
    pose. y>=1100, all hip/seat pixels and all current cloth pixels stay exact.
    """
    src = np.asarray(current.convert('RGBA')).copy()
    ref = np.asarray(donor.convert('RGBA')).copy()
    if src.shape != (1536,1024,4) or ref.shape != src.shape:
        raise ValueError('Expected the original registered 1024 x 1536 RGBA cels')
    if frame not in RIMS:
        raise ValueError(f'No reviewed cloth boundary for F{frame:03d}')
    yy, xx = np.indices(src.shape[:2], dtype=np.float32)

    # F078's old hanging-cloth outline covers the very top of this contour.
    # F099 has the same registered, exposed upper trouser outline with no
    # alpha crop. Use only that existing 31-pixel-high edge strip, tapering
    # into the fixed F078 outline below. Nothing is translated or scaled.
    if edge_donor is None:
        if frame in (90,93):
            raise ValueError('F090/F093 also need the registered F099 upper-edge donor')
        edge_donor=current
    edge = np.asarray(edge_donor.convert('RGBA'))
    if edge.shape != src.shape:
        raise ValueError('Upper-edge donor must use the same original canvas')
    ew = np.clip((1042-yy)/15,0,1)*(xx>804)*(yy>=997)*(yy<1042)
    ref=np.rint(ref.astype(np.float32)*(1-ew[:,:,None])+edge.astype(np.float32)*ew[:,:,None]).astype(np.uint8)

    # F078 contains the original continuous trouser outline. Its adjacent
    # hanging flower-cloth flap is excluded from the donor by a trouser-only
    # contour. The line itself stays the donor's existing antialiased line.
    # The first few pixels above y=1014 are its existing dark under-cloth
    # shading, needed only to restore the transparent notch in F090/F093.
    pant_right = 0.166*(yy-1040)+826.0
    # Keep all antialiasing on the original outer outline, while excluding
    # the old hanging cloth which is at least 7 px farther right here.
    donor_gate = np.clip(pant_right+4.0-xx,0,1)
    ref[:,:,3] = np.rint(ref[:,:,3]*donor_gate).astype(np.uint8)

    rim = RIMS[frame]
    exposed = aa_polygon(rim + [(868,1100),(662,1100)])
    # Feather inside the existing trouser shading. No feather crosses the
    # new flower-cloth rim. Upper artwork is retained until source y=1012.
    weight = np.clip((yy-1012)/36,0,1)
    # Missing alpha / clipped outline needs an opaque restoration, not a
    # translucent fade-in. Outer silhouette is also replaced as one contour.
    missing = (src[:,:,3]<230)&(ref[:,:,3]>230)&(xx>805)&(yy>=997)
    outer = (xx>pant_right-7)&(yy>=1000)
    weight[missing|outer] = 1
    weight *= exposed
    weight *= np.clip((xx-662)/6,0,1)
    weight[(xx>=852)|(yy>=1100)|(yy<997)] = 0
    # Do not copy the old donor cloth (or its shadow-line) into any area
    # where the donor is still above its own trouser region.
    weight[(yy<1012)&(xx<808)] = 0
    w = weight[:,:,None]
    result = np.rint(src.astype(np.float32)*(1-w)+ref.astype(np.float32)*w).clip(0,255).astype(np.uint8)
    return Image.fromarray(result,'RGBA'), Image.fromarray(np.rint(weight*255).astype(np.uint8),'L')


def save_verified(im, path):
    path.parent.mkdir(parents=True,exist_ok=True)
    payload = io.BytesIO(); im.save(payload,format='PNG'); data=payload.getvalue()
    Image.open(io.BytesIO(data)).load()
    temp=path.with_suffix('.writing.png')
    with temp.open('wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
    Image.open(temp).load()
    if temp.read_bytes()!=data:
        raise OSError(f'PNG write mismatch: {path}')
    os.replace(temp,path)


def opaque(im, color=(112,106,101,255)):
    bg=Image.new('RGBA',im.size,color); bg.alpha_composite(im); return bg.convert('RGB')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-dir',type=Path,default=ROOT/'adopted')
    ap.add_argument('--donor',type=Path,default=ROOT/'adopted/F078.png')
    ap.add_argument('--edge-donor',type=Path,default=ROOT/'adopted/F099.png')
    ap.add_argument('--output-dir',type=Path,default=ROOT/'diagnostics/support_fixed')
    ap.add_argument('--frames',nargs='+',type=int,default=list(IDS))
    args=ap.parse_args()
    if args.output_dir.resolve() == args.input_dir.resolve():
        raise ValueError('Use a separate output directory; install reviewed results separately')
    donor=Image.open(args.donor).convert('RGBA')
    edge_donor=Image.open(args.edge_donor).convert('RGBA')
    records=[]; comparisons=[]
    for f in args.frames:
        source=args.input_dir/f'F{f:03d}.png'
        before=Image.open(source).convert('RGBA')
        after,mask=repair_trouser_join(before,donor,f,edge_donor)
        dest=args.output_dir/'assets'/source.name
        save_verified(after,dest)
        save_verified(mask,args.output_dir/'masks'/source.name)
        a,b=np.asarray(before),np.asarray(after)
        diff=np.any(a!=b,axis=2)
        ys,xs=np.where(diff)
        crop=(635,945,900,1330)
        panel=Image.new('RGB',(530,415),(112,106,101))
        panel.paste(opaque(before).crop(crop),(0,30));panel.paste(opaque(after).crop(crop),(265,30))
        draw=ImageDraw.Draw(panel)
        draw.text((8,8),f'F{f:03d} BEFORE (1:1)',fill='white')
        draw.text((273,8),f'F{f:03d} AFTER (1:1)',fill='white')
        save_verified(panel,args.output_dir/'comparison'/f'F{f:03d}_BEFORE_AFTER_1X.png')
        comparisons.append(panel)
        records.append({'frame':f,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'output':str(dest),'changed_pixels':int(diff.sum()),
            'change_bbox':[int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1] if len(xs) else None,
            'pixels_y1100_and_below_exact':bool(np.array_equal(a[1100:],b[1100:])),
            'all_pixels_outside_semantic_mask_exact':bool(np.array_equal(a[np.asarray(mask)==0],b[np.asarray(mask)==0]))})
    overview=Image.new('RGB',(530*len(comparisons),415),(112,106,101))
    for i,panel in enumerate(comparisons):overview.paste(panel,(i*530,0))
    save_verified(overview,args.output_dir/'TROUSER_BEFORE_AFTER_1X.png')
    (args.output_dir/'REPAIR_MANIFEST.json').write_text(json.dumps({'donor':str(args.donor),'upper_edge_donor':str(args.edge_donor),'scope':'registered far-trouser exposed area above y1100 only','records':records},indent=2)+'\n')
    print(json.dumps(records,indent=2))


if __name__=='__main__':main()
