from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import numpy as np,json,hashlib
D=Path(__file__).resolve().parent;A=D.parent/'astra_three_shot_color_audit_20261018_1648';load=lambda p:np.array(Image.open(p).convert('RGBA'))
def poly(sz,points):m=Image.new('L',sz);ImageDraw.Draw(m).polygon(points,fill=255);return np.array(m)>0
def ell(sz,c):m=Image.new('L',sz);x,y,rx,ry=c;ImageDraw.Draw(m).ellipse((x-rx,y-ry,x+rx,y+ry),fill=255);return np.array(m)>0
def soften(m,px=5):return np.clip((ndimage.distance_transform_edt(m)-.5)/px,0,1)
def stats(z,m):return np.asarray(z[:,:,:3][m].mean(0))
def composite(a,c='#e4e1dc'):return Image.alpha_composite(Image.new('RGBA',(a.shape[1],a.shape[0]),c),Image.fromarray(a)).convert('RGB')
def save(shot,f,a,o,weights,protected,meta,box):
 P=D/f'{shot}_F{f:03d}';P.mkdir(exist_ok=True);p=P/f'{shot}_F{f:03d}_color_PROPOSAL.png';Image.fromarray(o).save(p);m=np.any(a!=o,2);Image.fromarray(m.astype('uint8')*255).save(P/'actual_difference_mask.png');Image.fromarray(protected.astype('uint8')*255).save(P/'hard_feature_protection_mask.png');union=np.zeros(m.shape,bool);vis=np.array(composite(a)).astype(float)
 for n,(name,w) in enumerate(weights.items()):
  Image.fromarray(np.rint(w*255).astype('uint8')).save(P/(name+'_semantic_weighted_mask.png'));union|=w>0;active=w>.25;vis[active]=.4*vis[active]+.6*np.array([(210,60,180),(30,200,130)][n%2])
 delta=o[:,:,:3].astype(int)-a[:,:,:3].astype(int);meta.update({'status':'PROPOSAL_ONLY_NOT_ADOPTED','source_commit':'d558a91bb2af071e635afd2456f7460d74b42fc5','source_sha256':hashlib.sha256((A/'sources'/shot/f'{shot}_F{f:03d}.png').read_bytes()).hexdigest(),'proposal_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'actual_changed_pixels':int(m.sum()),'delta_min_RGB':delta.min((0,1)).tolist(),'delta_max_RGB':delta.max((0,1)).tolist(),'alpha_changed':int(np.any(o[:,:,3]!=a[:,:,3])),'outside_semantic_weights_changed':int((m&~union).sum()),'hard_features_changed':int((m&protected).sum()),'no_geometry_resampling':True,'imagegen_calls':0});(P/'CHECKS.json').write_text(json.dumps(meta,indent=2))
 sheet=Image.new('RGB',(1500,680),'white');dr=ImageDraw.Draw(sheet)
 for j,(im,label) in enumerate([(composite(a),'ORIGINAL ADOPTED'),(composite(o),'COLOR PROPOSAL ONLY'),(Image.fromarray(vis.astype('uint8')),'ACTUAL SEMANTIC FILL WEIGHTS')]):
  q=im.crop(box);q.thumbnail((500,630));sheet.paste(q,(j*500+(500-q.width)//2,35));dr.text((j*500+8,10),f'{shot} F{f:03d} '+label,fill='black')
 sheet.save(P/'original_proposal_semantic_mask.jpg',quality=98);composite(o,'#273239').crop(box).save(P/'proposal_dark.png');return meta
reports={}
for f in [17,21,23]:
 shot='S03a';a=load(A/'sources'/shot/f'{shot}_F{f:03d}.png');H,W=a.shape[:2];Y,X=np.indices((H,W));r,g,b=a[:,:,:3].astype(float).transpose(2,0,1);lum=(r+g+b)/3
 region=(X>540)&(X<1190)&(Y>85)&(Y<620);hair=region&(a[:,:,3]>=245)&(r>47)&(r<90)&(g>35)&(b>28)&(r-g>3)&(r-b>8);ink=region&(lum<37);high=region&(lum>65);faceguard=poly((W,H),[(585,475),(620,443),(680,427),(754,427),(835,448),(892,485),(911,578),(899,644),(850,695),(740,735),(658,701),(600,649),(581,563)]);protected=ndimage.binary_dilation(ink|high,iterations=1)|faceguard;hair&=~protected;w=soften(hair,5);o=a.copy();o[:,:,0]=np.clip(np.rint(r-2*w),0,255).astype('uint8');m=np.array(Image.open(A/f'S03a_F{f:03d}_hair_brown_mask.png'))>0;base=load(A/'sources'/shot/'S03a_F000.png');bm=np.array(Image.open(A/'S03a_F000_hair_brown_mask.png'))>0;meta={'method':'R-2 in continuous brown crown fill;5px semantic-distance edge weight. No face, pig-tail, red tie, linework, geometry or alpha edit.','crown_mean_delta_after':(stats(o,m)-stats(base,bm)).round(5).tolist()};reports[shot]=save(shot,f,a,o,{'crown_hair':w},protected,meta,(540,90,1180,770))

(D/"S03a_COLOR_CHECKS.json").write_text(json.dumps(reports,indent=2))
